# Student Portfolio — Dark Futuristic

A responsive personal portfolio built with plain HTML, CSS, and JavaScript. It can be hosted free with GitHub Pages.

## Preview locally
1. Extract the ZIP file.
2. Open `index.html` in a browser.
3. For the most reliable local preview, use a simple local web server or the VS Code Live Server extension.

## Personalize it
1. Open `index.html` in any text editor.
2. Replace `Your Name` with your name.
3. Update the About, skills, projects, and education sections so they accurately describe you.
4. Open `script.js` and replace `your.email@example.com` with your real email address.
5. Save and refresh the browser.

The contact form opens the visitor's email application; it does not send or store messages on a server. The Google Fonts import needs an internet connection, but the page remains usable without it.

## Publish for free with GitHub Pages
1. Create or sign in to an account at https://github.com/
2. Create a new **public** repository, for example `student-portfolio`.
3. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository's root folder.
4. Open the repository's **Settings** → **Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch **main** and folder **/(root)**, then click **Save**.
7. Wait a minute or two. GitHub will show your public website URL on the Pages settings screen.

## Before sharing
- Replace all sample content with your own real details.
- Only publish contact information you are comfortable making public.
- The sample project cards are examples, not claims of completed work.
