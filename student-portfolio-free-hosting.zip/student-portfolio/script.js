// PERSONALIZE YOUR PORTFOLIO
// 1. Replace "Your Name" in index.html with your name.
// 2. Change the email below to your real email address.
// 3. Update the school, skills, and project examples in index.html.

const PORTFOLIO_EMAIL = "your.email@example.com";

document.title = "Student Portfolio | Your Name";
document.getElementById("year").textContent = new Date().getFullYear();

const emailDisplay = document.getElementById("email-display");
emailDisplay.textContent = PORTFOLIO_EMAIL;

const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "✕" : "☰";
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});

document.getElementById("copy-email").addEventListener("click", async () => {
  const status = document.getElementById("form-status");
  try {
    await navigator.clipboard.writeText(PORTFOLIO_EMAIL);
    status.textContent = "Email copied.";
  } catch {
    status.textContent = "Email: " + PORTFOLIO_EMAIL;
  }
});

document.getElementById("contact-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const status = document.getElementById("form-status");

  if (PORTFOLIO_EMAIL === "your.email@example.com") {
    status.textContent = "Please set PORTFOLIO_EMAIL in script.js to your real email first.";
    return;
  }

  const form = new FormData(event.currentTarget);
  const name = form.get("name");
  const senderEmail = form.get("email");
  const message = form.get("message");
  const subject = encodeURIComponent("Portfolio message from " + name);
  const body = encodeURIComponent(
    "Name: " + name + "\nEmail: " + senderEmail + "\n\nMessage:\n" + message
  );
  window.location.href = `mailto:${PORTFOLIO_EMAIL}?subject=${subject}&body=${body}`;
  status.textContent = "Your email app should open with the message ready.";
});
